<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\BlogResource;
use App\Models\Blog;
use App\Models\BlogView;
use App\Traits\ApiResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class BlogController extends Controller
{
    use ApiResponse;
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $blogs = Blog::latest()->get();

        if ($blogs->isEmpty()) {
            return $this->errorResponse([], 'لا توجد مدونات حالياً', 404);
        }

        return $this->successResponse(BlogResource::collection($blogs), 'تم جلب المدونات بنجاح');
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
    }

    /**
     * Display the specified resource.
     */
    public function show(Blog $blog)
    {
        if (!$blog) {
            return $this->errorResponse([], 'المدونة غير موجودة', 404);
        }

        return $this->successResponse(new BlogResource($blog), 'تم جلب المدونة بنجاح');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Blog $blog)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Blog $blog)
    {
        //
    }


    public function readBlog(string $id)
    {
        $blog = Blog::find($id);

        if (!$blog) {
            return $this->errorResponse([], 'المدونة غير موجودة', 404);
        }

        $user = Auth::user();

        if ($user) {
            $alreadyViewed = BlogView::where('user_id', $user->id)
                ->where('blog_id', $blog->id)
                ->exists();

            if (!$alreadyViewed) {
                $blog->increment('views_count');

                BlogView::create([
                    'user_id' => $user->id,
                    'blog_id' => $blog->id,
                ]);
            }
        }

        $recommendations = [];

        if ($blog->description) {
            try {
                $response = Http::post('https://ahmedelsherbeny-blog-recommendation.hf.space/recommend', [
                    'query' => $blog->description,
                    'top_k' => 5
                ]);

                dd($response->body());

                if ($response->successful()) {
                    $recommendations = $response->json();
                    dd($recommendations);
                }

            } catch (\Exception $e) {
                return response()->json([
                    'status' => false,
                    'message' => 'Recommendation API error: ' . $e->getMessage()
                ], 500);            }
        }

        return $this->successResponse([], 'تم جلب المدونة بنجاح');
    }

}
